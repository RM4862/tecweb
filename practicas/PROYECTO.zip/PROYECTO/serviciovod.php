<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es">

<?php
// VALIDACION
libxml_use_internal_errors(true);
$xml = new DOMDocument();
$documento = file_get_contents('serviciovodN_1.xml');
$xml->loadXML($documento, LIBXML_NOBLANKS);
$xsd = 'serviciovod4_1.xsd';
if (!$xml->schemaValidate($xsd)) {
    $errors = libxml_get_errors();
    $noError = 1;
    $lista = '';
    foreach ($errors as $error) {
        $lista = $lista . '[' . ($noError++) . ']: ' . $error->message . ' ';
    }
    echo $lista;
} else {
    // CONEXIÓN A LA BASE DE DATOS
    $link = new mysqli('localhost', 'root', '12345678a', 'catalogovod');
    if ($link->connect_errno) {
        die('Falló la conexión: ' . $link->connect_error . '<br/>');
    }

    

}
?>

<!--HTML-->
