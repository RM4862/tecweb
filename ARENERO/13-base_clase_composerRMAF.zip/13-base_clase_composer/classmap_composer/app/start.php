<?php
     require_once __DIR__ . '/../vendor/autoload.php'; // /../significa que salimos de la carpeta contenedora 
?>