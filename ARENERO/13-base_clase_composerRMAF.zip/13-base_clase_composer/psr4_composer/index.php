<?php
    use Webtechnologies\config\Dev as Dev; //se puede usar alias 
    include_once __DIR__ . '/app/start.php'; //hacemos referencia al documento que tiene a todos ls requires 
    //$user = new UserTemplate();
    //$user = new User();
    //$user = new UserController();
    $user = new Dev();
?>