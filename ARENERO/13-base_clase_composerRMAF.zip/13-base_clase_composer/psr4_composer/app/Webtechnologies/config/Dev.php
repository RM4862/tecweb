<?php //este es un archivo para simular el ambiente de produccion 
namespace Webtechnologies\config;
class Dev{
    public function __construct(){
        die('dev config');
    }
}
?>