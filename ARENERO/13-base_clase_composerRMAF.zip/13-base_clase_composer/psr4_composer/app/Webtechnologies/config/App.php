<?php //este es un archivo para simular el ambiente de produccion 
namespace Webtechnologies\config;
class App{
    public function __construct(){
        die('app config');
    }
}
?>