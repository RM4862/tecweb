<?php
class User {
    public function __construct() {
        die('User model');
    }
}
?>