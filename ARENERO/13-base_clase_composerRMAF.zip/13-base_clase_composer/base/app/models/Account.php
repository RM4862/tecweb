<?php
class Account {
    public function __construct() {
        die('Account model');
    }
}
?>