<?php
    namespace Webtechnologies\Models;
    class Account {
        public function __construct() {
            die('Account model');
        }
}
?>