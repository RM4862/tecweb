<?php
    namespace Webtechnologies\Controllers;
    class UserController {
        public function __construct() {
            die('User controller');
        }
    }
?>